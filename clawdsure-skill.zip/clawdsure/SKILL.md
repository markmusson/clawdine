---
name: Clawdsure
description: "Parametric insurance for AI agents. Enroll, run continuous security audits, sign daily attestations, pin to IPFS, and report to underwriting platform. Covers security incidents for agents maintaining unbroken attestation chains."
---

# Clawdsure Insurance Skill

## Goal
Enable AI agents to enroll in parametric insurance coverage, maintain continuous security attestations, and qualify for automatic payouts on verified security incidents.

## Non-negotiable safety rules
1. **Never exfiltrate private keys.** The `agent.key` file never leaves the host.
2. **Never fake attestations.** Every attestation must reflect actual audit results.
3. **Never skip audits.** Daily attestations require a fresh Clawdsure audit.
4. **Redact secrets** in all reports (tokens, passwords, API keys, OAuth credentials).
5. **Treat chain integrity as sacred.** A broken chain voids coverage until re-enrollment.

## Requirements
- OpenClaw installed and running
- `openclaw security audit` command available
- Network access to api.clawdsure.io

**No IPFS setup required** — Clawdsure handles pinning server-side.

## Workflow Overview

### Enrollment (one-time)
```
1. Run security audit (openclaw security audit)
2. Remediate any critical findings
3. Generate ECDSA keypair (agent identity)
4. Sign genesis attestation
5. POST to api.clawdsure.io/enroll
6. Clawdsure pins to IPFS, returns CID
7. Pay premium ($50/year basic)
8. Coverage active ✓
```

### Daily Attestation (continuous)
```
1. Run security audit
2. Sign attestation (links to previous via hash)
3. POST to api.clawdsure.io/attestation
4. Clawdsure pins to IPFS, returns CID
5. Chain grows: attestation₁ → attestation₂ → ... → attestationₙ
```

**Agents never touch IPFS directly.** Clawdsure handles pinning server-side.

### Incident (if breached)
```
1. Report incident with evidence
2. UW verifies chain was unbroken
3. UW verifies incident is covered
4. Automatic payout ($500 basic tier)
```

## Commands

### Enroll
Run `scripts/enroll.sh` to:
- Run initial audit & verify 0 critical findings
- Generate keypair if not exists
- Sign genesis attestation
- POST to Clawdsure API (handles IPFS pinning)

### Daily Attestation
Run `scripts/daily-attest.sh` to:
- Run security audit
- Sign attestation (hash-linked to previous)
- POST to Clawdsure API (handles IPFS pinning)

Set up automation via launchd (macOS) or systemd/cron (Linux).

**Token Efficiency:** The script is silent on success. Only outputs if:
- Critical findings detected (FAIL)
- Chain gap approaching 48h limit
- API errors requiring attention

This follows the principle: *scripts for logic, models for judgment*.

### Verify Chain
Run `scripts/verify-chain.sh` to:
- Validate all signatures in chain.jsonl
- Verify hash linking (each `prev` matches hash of previous)
- Check for gaps (timestamps >48h apart)
- Report chain health

### Report Incident
Run `scripts/report-incident.sh` to:
- Verify chain is unbroken
- Collect incident evidence
- Submit to UW platform for payout review

## Configuration

### Environment Variables
| Variable | Default | Description |
|----------|---------|-------------|
| `CLAWDSURE_DIR` | `~/.openclaw/workspace/.clawdsure` | Data directory |
| `CLAWDSURE_API` | `https://api.clawdsure.io/v1` | UW platform API |
| `PINATA_JWT` | (from `.pinata-jwt`) | IPFS pinning credential |

### Files
```
~/.openclaw/workspace/.clawdsure/
├── agent.key         # ECDSA private key (NEVER SHARE)
├── agent.pub         # ECDSA public key (registered with UW)
├── chain.jsonl       # Attestation chain (append-only)
├── pins.jsonl        # IPFS pin log
├── .pinata-jwt       # Pinata API key (mode 600)
└── enrollment.json   # Enrollment request (for records)
```

## References (read as needed)
- `references/underwriting.md` - UW criteria, pricing tiers, adjustments
- `references/attestation-schema.md` - Attestation record format
- `references/chain-rules.md` - Chain integrity rules and grace periods
- `references/incident-flow.md` - Incident reporting and payout process
- `references/api.md` - UW platform API specification

## Chain Integrity Rules

| Condition | Effect |
|-----------|--------|
| PASS attestation | Chain continues ✓ |
| FAIL (critical > 0) | 48h grace period to remediate |
| No attestation for 48h | Chain broken ✗ |
| Remediated within grace | Chain continues ✓ |
| Chain broken | Policy void until re-enrollment |

## Pricing Tiers

| Tier | Premium | Payout | Ratio |
|------|---------|--------|-------|
| Basic | $50/year | $500 | 10x |
| Pro | $200/year | $2,500 | 12.5x |
| Enterprise | Custom | Custom | Negotiated |

## Quick Start

```bash
# 1. Enroll
cd ~/.openclaw/workspace/skills/clawdsure
bash scripts/enroll.sh

# 2. Set up daily attestation (macOS)
cat > ~/Library/LaunchAgents/com.clawdsure.daily.plist << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.clawdsure.daily</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>~/.openclaw/workspace/skills/clawdsure/scripts/daily-attest.sh</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>9</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>~/.openclaw/workspace/.clawdsure/daily.log</string>
    <key>StandardErrorPath</key>
    <string>~/.openclaw/workspace/.clawdsure/daily.err</string>
</dict>
</plist>
EOF
launchctl load ~/Library/LaunchAgents/com.clawdsure.daily.plist

# 3. Verify coverage
bash scripts/verify-chain.sh
```

## Troubleshooting

### "Chain broken" error
Run `bash scripts/verify-chain.sh` to identify the gap. If within 48h of a FAIL, remediate and run `daily-attest.sh`. If >48h, must re-enroll.

### "No IPFS pin" warning
Configure Pinata JWT:
```bash
echo 'your-jwt-here' > ~/.openclaw/workspace/.clawdsure/.pinata-jwt
chmod 600 ~/.openclaw/workspace/.clawdsure/.pinata-jwt
```

### "API offline" info
Attestations still happen locally. Chain integrity preserved. Will sync when API available.
