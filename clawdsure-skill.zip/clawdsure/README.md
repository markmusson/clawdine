# Clawdsure

**Parametric insurance for AI agents.**

Prove you're secure via continuous attestation. Get paid if you're hacked anyway.

## Quick Start

```bash
# 1. Enroll
cd ~/.openclaw/workspace/skills/clawdsure
bash scripts/enroll.sh

# 2. Daily attestation (automate via cron/launchd)
bash scripts/daily-attest.sh

# 3. Verify chain anytime
bash scripts/verify-chain.sh
```

That's it. No IPFS config, no API keys, no extra setup.

## Token Efficiency

Scripts are **silent on success** — only output when attention needed:
- ✅ PASS attestation → logs to file, no model invocation
- ⚠️ FAIL attestation → alerts (needs remediation)
- ⚠️ Chain gap >36h → warns (approaching 48h limit)

For scheduled runs, use isolated sessions with cheap models:
```bash
# OpenClaw cron example
{
  "sessionTarget": "isolated",
  "payload": {
    "model": "anthropic/claude-haiku-4-5",
    "message": "bash scripts/daily-attest.sh"
  }
}
```

## How It Works

1. **Enroll**: Pass a security audit, generate identity, pay premium
2. **Attest Daily**: Run audit, sign attestation, pin to IPFS, report to UW
3. **Stay Covered**: Keep chain unbroken (no >48h gaps, remediate criticals)
4. **If Breached**: File incident report, get automatic payout

## Pricing

| Tier | Premium | Payout |
|------|---------|--------|
| Basic | $50/year | $500 |
| Pro | $200/year | $2,500 |

## Requirements

- OpenClaw installed and running
- 0 critical findings on `openclaw security audit`
- Network access to api.clawdsure.io

**No IPFS setup required** — Clawdsure handles pinning server-side.

## Files

```
~/.openclaw/workspace/.clawdsure/
├── agent.key       # Private key (KEEP SECRET)
├── agent.pub       # Public key
├── chain.jsonl     # Attestation chain
├── pins.jsonl      # IPFS pin log
└── .pinata-jwt     # Pinata API key
```

## Documentation

See `SKILL.md` for full usage and `references/` for specs.

## License

MIT

---

*"Trust, but verify. Continuously."*
