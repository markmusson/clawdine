# Underwriting Criteria & Pricing

## Eligibility Requirements

### Minimum Requirements (Basic Tier)
| Requirement | Criteria |
|-------------|----------|
| Platform | OpenClaw (verified via audit) |
| Audit Tool | openclaw security audit |
| Initial Audit | 0 critical findings |
| Identity | ECDSA keypair generated |
| Chain | Genesis attestation signed |

### Enhanced Requirements (Pro/Enterprise)
| Requirement | Criteria |
|-------------|----------|
| Audit History | 30+ days unbroken chain |
| Warnings | ≤2 at any point |
| Version | Within 2 minor versions of latest |
| IPFS | All attestations pinned |

## Pricing Tiers

### Basic ($50/year → $500 payout)
- Target segment: Individual operators, hobbyists
- Expected loss ratio: 40%
- Break-even: 10% incident rate (1 in 10 claims)
- Margin at 2% incident: $40/policy
- Margin at 5% incident: $25/policy

### Pro ($200/year → $2,500 payout)
- Target segment: Small businesses, serious operators
- Expected loss ratio: 35%
- Break-even: 8% incident rate
- Requires 30-day attestation history

### Enterprise (Custom)
- Target segment: Organizations, fleets
- Negotiated based on:
  - Fleet size
  - Audit history
  - Operational context
  - Custom coverage terms

## Premium Adjustments

### Discounts
| Factor | Adjustment |
|--------|------------|
| Continuous attestation >1 year | -10% |
| Zero warnings (trailing 90 days) | -5% |
| Pro tier upgrade from Basic | -5% first year |

### Surcharges
| Factor | Adjustment |
|--------|------------|
| Multiple critical remediations (trailing 90 days) | +20% |
| Public-facing gateway | +25% |
| Browser tools enabled | +15% |
| Elevated exec enabled | +20% |
| No IPFS pinning | +10% |

## Risk Scoring

### Audit-Based Risk Factors
```
Base Score: 100

Deductions:
- Critical finding (current): -50 each
- Warning (current): -5 each
- Critical remediated (90 days): -10 each
- Chain gap (48h+): -25 each
- Version outdated (>2 minor): -10

Additions:
- Clean audit streak (30+ days): +10
- Clean audit streak (90+ days): +20
- All attestations pinned: +5
```

### Risk Tiers
| Score | Tier | Effect |
|-------|------|--------|
| 90-100 | Excellent | Eligible for discounts |
| 70-89 | Good | Standard pricing |
| 50-69 | Fair | +10% surcharge |
| <50 | Poor | Ineligible / requires remediation |

## Actuarial Assumptions (v1)

### Incident Rate Estimates
Source: Munich Re cyber insurance data, Clawdine analysis

| Category | Rate | Notes |
|----------|------|-------|
| General cyber incidents | ~15%/year | All businesses |
| With continuous monitoring | ~5%/year | Security-conscious |
| With attestation + audit | ~2%/year | Best estimate for Clawdsure |

### Loss Distribution
| Incident Type | Frequency | Avg Severity |
|---------------|-----------|--------------|
| Credential theft | 40% | Low |
| Unauthorized access | 30% | Medium |
| Data exfiltration | 20% | High |
| Supply chain compromise | 10% | Critical |

### Reserve Requirements
- Maintain 3x expected annual losses in reserve
- At Basic tier: Reserve = 3 × (policies × $500 × 0.02) = 3% of payout capacity

## Exclusions

### Not Covered
1. Self-inflicted damage (user error, intentional misconfiguration)
2. Incidents during chain break (>48h gap)
3. Pre-existing vulnerabilities not disclosed at enrollment
4. Gross negligence (ignoring critical findings for >48h)
5. Social engineering (phishing, etc.) where no technical breach occurred
6. Loss of funds/crypto (financial loss not security incident)

### Coverage Disputes
1. Agent can appeal to arbitration panel
2. Chain integrity is deterministic (not disputable)
3. Incident classification may be disputed
4. 7-day resolution window

## Renewal

### Automatic Renewal
- 30 days before expiry: renewal notice
- If chain unbroken: auto-renew at same tier
- If chain broken: must re-enroll

### Upgrade Path
- Basic → Pro: Requires 30-day clean history
- Pro → Enterprise: Contact sales
