# Incident Reporting & Payout Flow

## Overview

When a security incident occurs, the agent (or owner) files an incident report. The UW platform verifies chain integrity and incident validity, then triggers automatic payout if conditions are met.

## Incident Types

### Covered Incidents

| Type | Code | Description | Evidence Required |
|------|------|-------------|-------------------|
| Unauthorized Access | `unauthorized_access` | Someone gained access without authorization | Logs, timestamps, IP/session info |
| Credential Theft | `credential_theft` | Tokens, keys, or passwords were exfiltrated | Logs showing access, compromise indicators |
| Data Exfiltration | `data_exfil` | Data was stolen from the system | Network logs, file access logs |
| Malicious Execution | `malicious_exec` | Unauthorized commands were executed | Command history, process logs |
| Supply Chain | `supply_chain` | Compromised skill/plugin installed | Skill/plugin audit trail |

### Not Covered

| Exclusion | Reason |
|-----------|--------|
| Self-inflicted | User error, intentional misconfiguration |
| During chain break | Coverage was void |
| Pre-existing | Known vulnerability at enrollment |
| Gross negligence | Ignored critical findings >48h |
| Social engineering | No technical breach occurred |
| Financial loss only | e.g., bad trades, lost crypto |

## Reporting Process

### Step 1: Verify Chain
Before filing, agent must verify chain is unbroken:
```bash
bash scripts/verify-chain.sh
```

If chain broken: No payout possible. Document incident for records but don't file claim.

### Step 2: Collect Evidence
Gather:
- Timestamp of incident (when detected, when occurred if known)
- Type of incident
- Description of what happened
- Supporting evidence:
  - Logs (redacted if containing secrets)
  - Screenshots
  - Network captures
  - Third-party notifications (e.g., breach alerts)

### Step 3: File Report
```bash
bash scripts/report-incident.sh
```

Interactive prompts collect:
- Incident type
- Date/time
- Description
- Evidence file paths

### Step 4: Await Verification
UW platform:
1. Receives signed incident report
2. Verifies chain was unbroken at incident time
3. Reviews evidence
4. Makes determination

### Step 5: Payout or Dispute
- **Approved**: Automatic payout to registered method
- **Denied**: Reason provided, appeal available

## Verification Process (UW Side)

### Chain Verification
```
1. Fetch latest chain from IPFS (known CID)
2. Verify all signatures
3. Verify hash linking
4. Check no gaps >48h before incident timestamp
5. Confirm agent ID matches registered agent
```

### Incident Verification
```
1. Review evidence
2. Cross-reference with attestation data:
   - Was there a FAIL around incident time?
   - Version at time of incident?
   - Known vulnerabilities in that version?
3. Assess if incident was:
   - Actually a security breach (vs user error)
   - Not self-inflicted
   - Not during coverage gap
4. Make determination
```

### Determination Outcomes

| Outcome | Criteria | Action |
|---------|----------|--------|
| APPROVED | Chain valid, incident verified, covered type | Trigger payout |
| DENIED_CHAIN | Chain broken at incident time | No payout, explain |
| DENIED_TYPE | Incident type not covered | No payout, explain |
| DENIED_EVIDENCE | Insufficient evidence | Request more info |
| DISPUTED | Borderline case | Escalate to arbitration |

## Payout

### Basic Tier
- Payout: $500
- Method: Registered payment method (Stripe, crypto, etc.)
- Timeline: Within 7 days of approval

### Pro Tier
- Payout: $2,500
- Same method and timeline

### Enterprise
- Payout: Per contract
- May involve additional verification

## Appeals

### Filing an Appeal
If claim denied:
1. Review denial reason
2. Gather additional evidence if available
3. File appeal within 14 days
4. Appeal reviewed by arbitration panel (not original reviewer)

### Arbitration Panel
- 3 independent reviewers
- Majority vote decides
- Decision is final
- 7-day resolution window

### Appeal Outcomes
- **Overturned**: Original decision reversed, payout triggered
- **Upheld**: Original denial stands
- **Partial**: Reduced payout (rare, for edge cases)

## Fraud Prevention

### Red Flags
- Multiple claims in short period
- Incident "discovered" right after policy purchase
- Vague or inconsistent evidence
- Attestation chain shows unusual patterns
- Public key changed recently

### Investigation Triggers
- Any claim >$1000
- Second claim from same agent
- Pattern matching known fraud attempts
- Whistleblower tips

### Fraud Consequences
- Claim denied
- Policy terminated
- Agent blacklisted
- May pursue legal action

## Reporting Timeline

| Event | Deadline |
|-------|----------|
| Incident occurs | - |
| Incident detected | - |
| Report filed | Within 30 days of detection |
| UW verification | 7 days from report |
| Payout (if approved) | 7 days from approval |
| Appeal (if denied) | Within 14 days of denial |
| Appeal resolution | 7 days from appeal |

## Example Flow

```
Day 0, 14:00:  Incident occurs (unauthorized access)
Day 0, 18:00:  Agent detects suspicious activity
Day 0, 18:30:  Agent runs verify-chain.sh → VALID
Day 0, 19:00:  Agent files incident report
Day 2:         UW receives and begins verification
Day 3:         UW verifies chain (unbroken at incident time)
Day 5:         UW reviews evidence, determines APPROVED
Day 7:         $500 payout initiated
Day 10:        Payout received
```

## Post-Incident

After a claim:
1. Continue daily attestations (coverage continues)
2. Premium may adjust at renewal based on claim history
3. Second claim in same year: +50% premium next term
4. Third claim: Policy review required
