# Clawdsure API Specification

The Clawdsure API handles all IPFS pinning server-side. Agents sign attestations locally and POST them to the API. The API:
1. Verifies the signature against the registered public key
2. Pins the attestation to public IPFS
3. Returns the CID to the agent
4. Makes data available to the oracle

**Agents never need to configure IPFS.**

## Base URL
```
Production: https://api.clawdsure.io/v1
Staging:    https://api-staging.clawdsure.io/v1
```

## Authentication

All requests must include:
```
X-Agent-ID: CLWD-XXXXXXXX
X-Agent-Signature: <base64-signature>
```

Signature covers the request body:
```bash
SIG=$(echo -n "$REQUEST_BODY" | openssl dgst -sha256 -sign agent.key | base64 -w0)
```

## Endpoints

### Health Check
```
GET /health

Response:
{
  "status": "ok",
  "version": "1.0.0",
  "timestamp": "2026-02-07T12:00:00Z"
}
```

### Enroll
```
POST /enroll

Request:
{
  "action": "enroll",
  "agent": {
    "id": "CLWD-FFF4D493",
    "fingerprint": "fff4d493...",
    "publicKey": "<base64-pem>"
  },
  "genesis": {
    "attestation": { ... },
    "timestamp": "2026-02-07T10:00:00Z"
  },
  "audit": {
    "tool": "openclaw-security-audit",
    "version": "2026.2.6-3",
    "result": "PASS",
    "findings": {
      "critical": 0,
      "warn": 1,
      "info": 2
    }
  },
  "policy": {
    "tier": "basic",
    "premium": 50,
    "payout": 500,
    "term": "annual"
  }
}

Response (success):
{
  "status": "enrolled",
  "agentId": "CLWD-FFF4D493",
  "policyId": "POL-2026-000123",
  "genesisCid": "bafkrei...",
  "ipfsUrl": "https://ipfs.io/ipfs/bafkrei...",
  "paymentUrl": "https://clawdsure.io/pay/POL-2026-000123",
  "expiresAt": "2027-02-07T10:00:00Z"
}

Response (error):
{
  "status": "error",
  "code": "CRITICAL_FINDINGS",
  "message": "Cannot enroll with critical findings"
}
```

### Submit Attestation
```
POST /attestation

Request:
{
  "action": "attestation",
  "agent": {
    "id": "CLWD-FFF4D493",
    "fingerprint": "fff4d493..."
  },
  "attestation": {
    "seq": 42,
    "prev": "...",
    "ts": "...",
    "agent": "CLWD-FFF4D493",
    "result": "PASS",
    "critical": 0,
    "warn": 1,
    "info": 2,
    "version": "...",
    "sig": "..."
  },
  "chain": {
    "length": 42,
    "prevHash": "..."
  }
}

Response (success):
{
  "status": "accepted",
  "seq": 42,
  "cid": "bafkrei...",
  "ipfsUrl": "https://ipfs.io/ipfs/bafkrei...",
  "chainStatus": "valid",
  "nextDue": "2026-02-09T10:00:00Z"
}

Response (grace period):
{
  "status": "accepted",
  "seq": 42,
  "cid": "bafkrei...",
  "chainStatus": "grace",
  "gracePeriodEnds": "2026-02-09T09:00:00Z",
  "message": "Critical findings detected. Remediate within 48h."
}

Response (chain broken):
{
  "status": "rejected",
  "code": "CHAIN_BROKEN",
  "message": "Attestation gap >48h. Re-enrollment required.",
  "lastValidSeq": 40,
  "gapStart": "2026-02-05T09:00:00Z"
}
```

### Report Incident
```
POST /incident

Request:
{
  "action": "incident",
  "agent": {
    "id": "CLWD-FFF4D493",
    "fingerprint": "fff4d493..."
  },
  "incident": {
    "type": "unauthorized_access",
    "occurredAt": "2026-02-06T14:30:00Z",
    "reportedAt": "2026-02-06T18:00:00Z",
    "description": "Detected unauthorized SSH session..."
  },
  "chain": {
    "length": 42,
    "latestCid": "Qm...",
    "verified": true
  },
  "policy": {
    "tier": "basic",
    "payout": 500
  }
}

Response (received):
{
  "status": "received",
  "incidentId": "INC-2026-000456",
  "verificationStatus": "pending",
  "estimatedResolution": "2026-02-13T18:00:00Z"
}

Response (chain invalid):
{
  "status": "rejected",
  "code": "CHAIN_BROKEN",
  "message": "Chain was broken at time of incident. No coverage."
}
```

### Get Policy Status
```
GET /policy/:agentId

Response:
{
  "agentId": "CLWD-FFF4D493",
  "policyId": "POL-2026-000123",
  "tier": "basic",
  "status": "active",
  "enrolledAt": "2026-02-07T10:00:00Z",
  "expiresAt": "2027-02-07T10:00:00Z",
  "chainStatus": "valid",
  "chainLength": 42,
  "lastAttestation": "2026-02-07T09:00:00Z",
  "claims": [],
  "premium": 50,
  "payout": 500
}
```

### Get Chain Status
```
GET /chain/:agentId

Response:
{
  "agentId": "CLWD-FFF4D493",
  "status": "valid",
  "length": 42,
  "genesisTs": "2026-02-07T10:00:00Z",
  "latestTs": "2026-03-20T09:00:00Z",
  "latestCid": "Qm...",
  "gaps": [],
  "failCount": 2,
  "remediatedCount": 2
}
```

### Get Incident Status
```
GET /incident/:incidentId

Response:
{
  "incidentId": "INC-2026-000456",
  "agentId": "CLWD-FFF4D493",
  "status": "under_review",
  "type": "unauthorized_access",
  "reportedAt": "2026-02-06T18:00:00Z",
  "chainValidAt": true,
  "reviewNotes": "Awaiting additional evidence",
  "estimatedResolution": "2026-02-13T18:00:00Z"
}
```

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INVALID_SIGNATURE` | 401 | Signature verification failed |
| `UNKNOWN_AGENT` | 404 | Agent not registered |
| `CHAIN_BROKEN` | 400 | Attestation chain invalid |
| `CRITICAL_FINDINGS` | 400 | Cannot enroll/attest with criticals |
| `DUPLICATE_SEQ` | 409 | Sequence number already exists |
| `GAP_TOO_LARGE` | 400 | >48h since last attestation |
| `POLICY_EXPIRED` | 402 | Policy not active |
| `RATE_LIMITED` | 429 | Too many requests |

## Rate Limits

| Endpoint | Limit |
|----------|-------|
| `/attestation` | 10/hour |
| `/enroll` | 3/day |
| `/incident` | 5/day |
| `/policy/:id` | 60/hour |
| `/chain/:id` | 60/hour |

## Webhooks (Future)

Agents can register webhooks for:
- `chain.grace_period` - 48h countdown started
- `chain.broken` - Coverage void
- `policy.expiring` - 30 days to renewal
- `incident.resolved` - Claim determination made

```
POST /webhooks

{
  "url": "https://myagent.example.com/webhook",
  "events": ["chain.grace_period", "incident.resolved"],
  "secret": "webhook-signing-secret"
}
```

## SDK (Planned)

```bash
# npm
npm install @clawdsure/sdk

# Python
pip install clawdsure
```

```javascript
import { ClawdsureClient } from '@clawdsure/sdk';

const client = new ClawdsureClient({
  agentId: 'CLWD-FFF4D493',
  privateKey: fs.readFileSync('agent.key'),
});

await client.submitAttestation(attestation);
await client.reportIncident(incident);
```
