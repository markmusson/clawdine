# Attestation Record Schema

## Standard Attestation

```json
{
  "seq": 42,
  "prev": "sha256-hash-of-previous-attestation",
  "ts": "2026-03-15T09:00:00Z",
  "agent": "CLWD-FFF4D493",
  "result": "PASS",
  "critical": 0,
  "warn": 1,
  "info": 2,
  "version": "2026.2.6-3",
  "sig": "base64-ecdsa-signature"
}
```

## Field Definitions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `seq` | integer | ✓ | Sequence number (1-indexed, monotonic) |
| `prev` | string | ✓ | SHA-256 hash of previous attestation (or "genesis" for first) |
| `ts` | string | ✓ | ISO 8601 timestamp in UTC |
| `agent` | string | ✓ | Agent ID (CLWD-XXXXXXXX format) |
| `result` | string | ✓ | "PASS" or "FAIL" |
| `critical` | integer | ✓ | Count of critical findings |
| `warn` | integer | ✓ | Count of warning findings |
| `info` | integer | ✓ | Count of informational findings |
| `version` | string | ✓ | OpenClaw version string |
| `sig` | string | ✓ | Base64-encoded ECDSA signature |

## Genesis Attestation (Extended)

First attestation includes additional enrollment fields:

```json
{
  "seq": 1,
  "prev": "genesis",
  "ts": "2026-02-07T10:00:00Z",
  "agent": "CLWD-FFF4D493",
  "fingerprint": "fff4d493084465f4a5563f741f44ecbbf4055eb9c829e5677c9ae91ef6c40177",
  "result": "PASS",
  "critical": 0,
  "warn": 1,
  "info": 2,
  "version": "2026.2.6-3",
  "enrollment": true,
  "sig": "base64-ecdsa-signature"
}
```

### Genesis-Only Fields

| Field | Type | Description |
|-------|------|-------------|
| `fingerprint` | string | Full SHA-256 fingerprint (64 chars) |
| `enrollment` | boolean | Always `true` for genesis |

## Agent ID Format

```
CLWD-XXXXXXXX
     ^^^^^^^^
     First 8 chars of fingerprint (uppercase)
```

Example:
- Fingerprint: `fff4d493084465f4a5563f741f44ecbbf4055eb9c829e5677c9ae91ef6c40177`
- Agent ID: `CLWD-FFF4D493`

## Fingerprint Derivation

```bash
# From public key file
shasum -a 256 agent.pub | cut -c1-64
```

The fingerprint is the SHA-256 hash of the PEM-encoded public key file contents (including headers).

## Signature

### What is Signed
The signature covers the JSON attestation **without** the `sig` field:

```bash
# Create unsigned attestation
UNSIGNED='{"seq":42,"prev":"abc...","ts":"...","agent":"...","result":"PASS",...}'

# Sign with ECDSA
echo -n "$UNSIGNED" | openssl dgst -sha256 -sign agent.key | base64 -w0
```

### Verification
```bash
# Extract unsigned portion
UNSIGNED=$(echo "$ATTESTATION" | jq -c 'del(.sig)')
SIG=$(echo "$ATTESTATION" | jq -r '.sig')

# Verify
echo -n "$UNSIGNED" | openssl dgst -sha256 -verify agent.pub -signature <(echo "$SIG" | base64 -d)
```

## Chain File Format

The chain is stored in `chain.jsonl` (JSON Lines format):

```jsonl
{"seq":1,"prev":"genesis","ts":"2026-02-07T10:00:00Z","agent":"CLWD-FFF4D493","result":"PASS",...,"sig":"..."}
{"seq":2,"prev":"a1b2c3...","ts":"2026-02-08T09:00:00Z","agent":"CLWD-FFF4D493","result":"PASS",...,"sig":"..."}
{"seq":3,"prev":"d4e5f6...","ts":"2026-02-09T09:00:00Z","agent":"CLWD-FFF4D493","result":"PASS",...,"sig":"..."}
```

### Properties
- One attestation per line
- Append-only (never modify existing lines)
- `prev` of line N = SHA-256 of line N-1
- Sequence numbers are consecutive (no gaps)

## Hash Linking

Each attestation's `prev` field contains the SHA-256 hash of the **entire previous line** (including signature):

```bash
# Hash of previous attestation (full JSON line)
PREV_HASH=$(tail -1 chain.jsonl | shasum -a 256 | cut -c1-64)
```

This creates a tamper-evident chain:
- Modifying any attestation breaks all subsequent `prev` hashes
- IPFS CIDs provide additional content-addressing
- Combined: cryptographic proof of chain integrity

## Result Values

| Value | Meaning | Chain Effect |
|-------|---------|--------------|
| `PASS` | 0 critical findings | Chain continues |
| `FAIL` | ≥1 critical finding | 48h grace period |

Note: Warnings and infos don't affect result. Only criticals cause FAIL.

## Validation Rules

### Per-Attestation
1. `seq` must equal line number in file
2. `prev` must match SHA-256 of previous line (or "genesis" for seq=1)
3. `sig` must verify against registered public key
4. `ts` must be valid ISO 8601 UTC timestamp
5. `result` must be "PASS" or "FAIL"
6. Counts must be non-negative integers

### Chain-Wide
1. No gaps in sequence numbers
2. Timestamps must be monotonically increasing
3. No timestamp gap >48h (chain break)
4. All agent IDs must match
