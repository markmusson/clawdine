#!/bin/bash
# Clawdsure Incident Reporting
# Verify chain → Collect evidence → Submit for payout
set -euo pipefail

CLAWDSURE_DIR="${CLAWDSURE_DIR:-$HOME/.openclaw/workspace/.clawdsure}"
API_BASE="${CLAWDSURE_API:-https://api.clawdsure.io/v1}"

if [ ! -f "$CLAWDSURE_DIR/agent.key" ]; then
  echo "❌ Not enrolled"
  exit 1
fi

cd "$CLAWDSURE_DIR"

FINGERPRINT=$(shasum -a 256 agent.pub | cut -c1-64)
AGENT_ID="CLWD-$(echo $FINGERPRINT | cut -c1-8 | tr 'a-f' 'A-F')"

echo "🚨 INCIDENT REPORT: $AGENT_ID"
echo "============================"
echo ""

# Step 1: Verify chain first
echo "1️⃣  Verifying attestation chain..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! bash "$SCRIPT_DIR/verify-chain.sh" >/dev/null 2>&1; then
  echo "   ❌ Chain verification failed"
  echo "   Cannot file claim with broken chain."
  echo ""
  echo "   Run: bash verify-chain.sh"
  exit 1
fi

CHAIN_LENGTH=$(wc -l < chain.jsonl | tr -d ' ')
LATEST_CID=$(tail -1 pins.jsonl 2>/dev/null | jq -r '.cid // "none"' 2>/dev/null || echo "none")
echo "   ✓ Chain valid ($CHAIN_LENGTH attestations)"
echo "   Latest CID: $LATEST_CID"

# Step 2: Collect incident details
echo ""
echo "2️⃣  Incident details"
echo ""

read -p "Incident type (breach/unauthorized_access/data_exfil/other): " INCIDENT_TYPE
read -p "Date/time of incident (YYYY-MM-DDTHH:MM:SSZ or 'now'): " INCIDENT_TIME
if [ "$INCIDENT_TIME" = "now" ]; then
  INCIDENT_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
fi

echo ""
echo "Describe what happened (end with EOF on its own line):"
DESCRIPTION=""
while IFS= read -r line; do
  [ "$line" = "EOF" ] && break
  DESCRIPTION+="$line\n"
done

echo ""
read -p "Any evidence files to attach? (comma-separated paths, or 'none'): " EVIDENCE_PATHS

# Step 3: Build incident report
echo ""
echo "3️⃣  Building incident report..."

REPORT_TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

INCIDENT_REPORT=$(cat << EOF
{
  "action": "incident",
  "agent": {
    "id": "$AGENT_ID",
    "fingerprint": "$FINGERPRINT"
  },
  "incident": {
    "type": "$INCIDENT_TYPE",
    "occurredAt": "$INCIDENT_TIME",
    "reportedAt": "$REPORT_TS",
    "description": "$(echo -e "$DESCRIPTION" | jq -Rs '.' | sed 's/^"//;s/"$//')"
  },
  "chain": {
    "length": $CHAIN_LENGTH,
    "latestCid": "$LATEST_CID",
    "verified": true
  },
  "policy": {
    "tier": "basic",
    "payout": 500
  }
}
EOF
)

# Sign report
REPORT_SIG=$(echo -n "$INCIDENT_REPORT" | openssl dgst -sha256 -sign agent.key 2>/dev/null | base64 | tr -d '\n')

# Save locally
mkdir -p incidents
INCIDENT_ID="INC-$(date +%s)"
echo "$INCIDENT_REPORT" > "incidents/$INCIDENT_ID.json"
echo "$REPORT_SIG" > "incidents/$INCIDENT_ID.sig"
echo "   ✓ Saved to incidents/$INCIDENT_ID.json"

# Step 4: Submit to UW platform
echo ""
echo "4️⃣  Submitting to UW platform..."

if curl -s --max-time 5 "$API_BASE/health" >/dev/null 2>&1; then
  API_RESPONSE=$(curl -s -X POST "$API_BASE/incident" \
    -H "Content-Type: application/json" \
    -H "X-Agent-ID: $AGENT_ID" \
    -H "X-Agent-Signature: $REPORT_SIG" \
    -d "$INCIDENT_REPORT" 2>/dev/null || echo '{"status":"error"}')
  echo "   API: $API_RESPONSE"
else
  echo "   ℹ️  API offline"
  echo "   Report saved locally. Submit manually when available."
fi

# Summary
echo ""
echo "========================================"
echo "📋 INCIDENT REPORT FILED"
echo "========================================"
echo "Incident ID:  $INCIDENT_ID"
echo "Type:         $INCIDENT_TYPE"
echo "Occurred:     $INCIDENT_TIME"
echo "Chain Status: Valid ($CHAIN_LENGTH attestations)"
echo ""
echo "Next steps:"
echo "  1. UW platform reviews chain integrity"
echo "  2. UW platform verifies incident"
echo "  3. If approved: automatic \$500 payout"
echo ""
echo "Track status at: https://clawdsure.io/incident/$INCIDENT_ID"
