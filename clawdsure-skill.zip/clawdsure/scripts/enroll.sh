#!/bin/bash
# Clawdsure Enrollment
# Audit → Generate Identity → Genesis Attestation → IPFS → UW Submit
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${CLAWDSURE_DIR:-$HOME/.openclaw/workspace/.clawdsure}"
API_BASE="${CLAWDSURE_API:-https://api.clawdsure.io/v1}"

echo "🛡️  CLAWDSURE ENROLLMENT"
echo "========================"
echo ""

# Step 1: Check OpenClaw is available
echo "1️⃣  Checking OpenClaw..."
if ! command -v openclaw >/dev/null 2>&1; then
  echo "   ❌ OpenClaw not installed"
  echo "   Install from: https://github.com/openclaw/openclaw"
  exit 1
fi
echo "   ✓ OpenClaw available"

# Step 2: Run security audit
echo ""
echo "2️⃣  Running security audit..."
AUDIT_OUTPUT=$(openclaw security audit 2>&1 || true)

CRITICAL=$(echo "$AUDIT_OUTPUT" | grep -oE '[0-9]+ critical' | grep -oE '[0-9]+' | head -1 || echo "0")
WARN=$(echo "$AUDIT_OUTPUT" | grep -oE '[0-9]+ warn' | grep -oE '[0-9]+' | head -1 || echo "0")
INFO=$(echo "$AUDIT_OUTPUT" | grep -oE '[0-9]+ info' | grep -oE '[0-9]+' | head -1 || echo "0")

CRITICAL=${CRITICAL:-0}
WARN=${WARN:-0}
INFO=${INFO:-0}

if [ "$CRITICAL" -gt 0 ]; then
  echo "   ❌ FAIL: $CRITICAL critical findings"
  echo ""
  echo "   Remediate before enrolling. Run:"
  echo "   openclaw security audit"
  exit 1
fi
echo "   ✓ PASS: 0 critical, $WARN warn, $INFO info"

# Step 3: Generate identity
echo ""
echo "3️⃣  Setting up agent identity..."
mkdir -p "$DATA_DIR"
cd "$DATA_DIR"

if [ ! -f agent.key ]; then
  openssl ecparam -genkey -name prime256v1 -noout -out agent.key 2>/dev/null
  openssl ec -in agent.key -pubout -out agent.pub 2>/dev/null
  chmod 600 agent.key
  echo "   ✓ Generated new ECDSA keypair"
else
  echo "   ✓ Using existing keypair"
fi

# Compute fingerprint
FINGERPRINT=$(shasum -a 256 agent.pub | cut -c1-64)
AGENT_ID="CLWD-$(echo $FINGERPRINT | cut -c1-8 | tr 'a-f' 'A-F')"
echo "   Agent ID:    $AGENT_ID"
echo "   Fingerprint: ${FINGERPRINT:0:16}..."

# Step 4: Genesis attestation
echo ""
echo "4️⃣  Creating genesis attestation..."
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
VERSION=$(openclaw --version 2>&1 | tail -1 || echo "unknown")

GENESIS=$(cat << EOF
{"seq":1,"prev":"genesis","ts":"$TIMESTAMP","agent":"$AGENT_ID","fingerprint":"$FINGERPRINT","result":"PASS","critical":0,"warn":$WARN,"info":$INFO,"version":"$VERSION","enrollment":true}
EOF
)

# Sign genesis
SIG=$(echo -n "$GENESIS" | openssl dgst -sha256 -sign agent.key 2>/dev/null | base64 | tr -d '\n')
SIGNED_GENESIS="${GENESIS%\}},\"sig\":\"$SIG\"}"

# Write chain
echo "$SIGNED_GENESIS" > chain.jsonl
echo "   ✓ Genesis attestation #1 signed"

# Step 5: Pin to IPFS (optional - uses auto-detection)
echo ""
echo "5️⃣  Pinning to IPFS..."
CID=$(bash "$SCRIPT_DIR/pin-chain.sh" 2>/dev/null || echo "none")

if [ "$CID" != "none" ] && [ -n "$CID" ]; then
  echo "   ✓ CID: $CID"
else
  echo "   ⏭️  Skipped (no pinning configured)"
  echo "   Run: bash scripts/setup-pinning.sh  (optional, 2 clicks)"
  CID="none"
fi

# Step 6: Create enrollment request
echo ""
echo "6️⃣  Creating enrollment request..."

PUBLIC_KEY_B64=$(base64 < agent.pub | tr -d '\n')

ENROLLMENT=$(cat << EOF
{
  "action": "enroll",
  "agent": {
    "id": "$AGENT_ID",
    "fingerprint": "$FINGERPRINT",
    "publicKey": "$PUBLIC_KEY_B64"
  },
  "genesis": {
    "attestation": $SIGNED_GENESIS,
    "ipfsCid": "$CID",
    "timestamp": "$TIMESTAMP"
  },
  "audit": {
    "tool": "openclaw-security-audit",
    "version": "$VERSION",
    "result": "PASS",
    "findings": {
      "critical": 0,
      "warn": $WARN,
      "info": $INFO
    }
  },
  "policy": {
    "tier": "basic",
    "premium": 50,
    "payout": 500,
    "term": "annual"
  }
}
EOF
)

echo "$ENROLLMENT" > enrollment.json
ENROLLMENT_SIG=$(echo -n "$ENROLLMENT" | openssl dgst -sha256 -sign agent.key 2>/dev/null | base64 | tr -d '\n')
echo "$ENROLLMENT_SIG" > enrollment.sig
echo "   ✓ Enrollment request created"

# Step 7: Submit to UW platform
echo ""
echo "7️⃣  Submitting to UW platform..."

if curl -s --max-time 5 "$API_BASE/health" >/dev/null 2>&1; then
  RESPONSE=$(curl -s -X POST "$API_BASE/enroll" \
    -H "Content-Type: application/json" \
    -H "X-Agent-ID: $AGENT_ID" \
    -H "X-Agent-Signature: $ENROLLMENT_SIG" \
    -d "@enrollment.json" 2>/dev/null || echo '{"status":"error"}')
  echo "   API: $RESPONSE"
else
  echo "   ℹ️  UW platform offline (local mode)"
  echo "   Request saved to: enrollment.json"
fi

# Summary
echo ""
echo "========================================"
echo "📋 ENROLLMENT SUMMARY"
echo "========================================"
echo "Agent ID:     $AGENT_ID"
echo "Fingerprint:  ${FINGERPRINT:0:16}..."
echo "Genesis CID:  $CID"
echo "Audit:        PASS (0 crit, $WARN warn, $INFO info)"
echo "Policy:       Basic (\$50/year → \$500 payout)"
echo ""
echo "Files:"
echo "  $DATA_DIR/"
echo "  ├── agent.key      (KEEP SECRET)"
echo "  ├── agent.pub"
echo "  ├── chain.jsonl"
echo "  └── enrollment.json"
echo ""
if [ "$CID" = "none" ]; then
  echo "💡 Enable IPFS pinning (optional):"
  echo "   bash scripts/setup-pinning.sh"
  echo ""
fi
echo "Next: Set up daily attestation"
echo "   bash scripts/daily-attest.sh"
echo ""
echo "✅ Enrollment complete"
