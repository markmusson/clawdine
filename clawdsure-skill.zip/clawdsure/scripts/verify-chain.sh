#!/bin/bash
# Clawdsure Chain Verification
# Validates signatures, hash linking, and continuity
set -euo pipefail

CLAWDSURE_DIR="${CLAWDSURE_DIR:-$HOME/.openclaw/workspace/.clawdsure}"

if [ ! -f "$CLAWDSURE_DIR/chain.jsonl" ]; then
  echo "❌ No chain.jsonl found"
  exit 1
fi

if [ ! -f "$CLAWDSURE_DIR/agent.pub" ]; then
  echo "❌ No agent.pub found"
  exit 1
fi

cd "$CLAWDSURE_DIR"

echo "🔍 CHAIN VERIFICATION"
echo "====================="
echo ""

ERRORS=0
WARNINGS=0
PREV_HASH="genesis"
PREV_TS=""
LINE_NUM=0
TOTAL_LINES=$(wc -l < chain.jsonl | tr -d ' ')

while IFS= read -r line; do
  LINE_NUM=$((LINE_NUM + 1))
  
  # Parse attestation
  SEQ=$(echo "$line" | jq -r '.seq' 2>/dev/null || echo "")
  PREV=$(echo "$line" | jq -r '.prev' 2>/dev/null || echo "")
  TS=$(echo "$line" | jq -r '.ts' 2>/dev/null || echo "")
  RESULT=$(echo "$line" | jq -r '.result' 2>/dev/null || echo "")
  SIG=$(echo "$line" | jq -r '.sig' 2>/dev/null || echo "")
  
  # Remove signature for verification
  UNSIGNED=$(echo "$line" | jq -c 'del(.sig)' 2>/dev/null || echo "")
  
  echo "Attestation #$SEQ ($TS)"
  
  # Check 1: Sequence number
  if [ "$SEQ" != "$LINE_NUM" ]; then
    echo "  ❌ Sequence mismatch: expected $LINE_NUM, got $SEQ"
    ERRORS=$((ERRORS + 1))
  fi
  
  # Check 2: Hash linking
  if [ "$PREV" != "$PREV_HASH" ]; then
    echo "  ❌ Hash link broken"
    echo "     Expected: ${PREV_HASH:0:16}..."
    echo "     Got:      ${PREV:0:16}..."
    ERRORS=$((ERRORS + 1))
  else
    echo "  ✓ Hash link valid"
  fi
  
  # Check 3: Signature verification
  SIG_VALID=false
  if [ -n "$SIG" ] && [ -n "$UNSIGNED" ]; then
    # Verify signature
    echo -n "$UNSIGNED" | openssl dgst -sha256 -verify agent.pub -signature <(echo "$SIG" | base64 -d 2>/dev/null) >/dev/null 2>&1&& SIG_VALID=true
  fi
  
  if [ "$SIG_VALID" = true ]; then
    echo "  ✓ Signature valid"
  else
    echo "  ❌ Signature invalid or missing"
    ERRORS=$((ERRORS + 1))
  fi
  
  # Check 4: Time gap (48h max)
  if [ -n "$PREV_TS" ] && [ -n "$TS" ]; then
    # Convert to epoch (macOS compatible)
    if command -v gdate >/dev/null 2>&1; then
      CURR_EPOCH=$(gdate -d "$TS" +%s 2>/dev/null || echo "0")
      PREV_EPOCH=$(gdate -d "$PREV_TS" +%s 2>/dev/null || echo "0")
    else
      CURR_EPOCH=$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "$TS" +%s 2>/dev/null || echo "0")
      PREV_EPOCH=$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "$PREV_TS" +%s 2>/dev/null || echo "0")
    fi
    
    if [ "$CURR_EPOCH" -gt 0 ] && [ "$PREV_EPOCH" -gt 0 ]; then
      GAP_HOURS=$(( (CURR_EPOCH - PREV_EPOCH) / 3600 ))
      if [ "$GAP_HOURS" -gt 48 ]; then
        echo "  ❌ Time gap: ${GAP_HOURS}h (>48h = chain break)"
        ERRORS=$((ERRORS + 1))
      elif [ "$GAP_HOURS" -gt 36 ]; then
        echo "  ⚠️  Time gap: ${GAP_HOURS}h (approaching 48h limit)"
        WARNINGS=$((WARNINGS + 1))
      fi
    fi
  fi
  
  # Check 5: Result
  if [ "$RESULT" = "FAIL" ]; then
    echo "  ⚠️  Result: FAIL (critical findings at this time)"
    WARNINGS=$((WARNINGS + 1))
  fi
  
  # Update for next iteration
  PREV_HASH=$(echo "$line" | shasum -a 256 | cut -c1-64)
  PREV_TS="$TS"
  echo ""
  
done < chain.jsonl

# Summary
echo "========================================"
echo "📋 VERIFICATION SUMMARY"
echo "========================================"
echo "Total attestations: $TOTAL_LINES"
echo "Errors:            $ERRORS"
echo "Warnings:          $WARNINGS"
echo ""

if [ "$ERRORS" -gt 0 ]; then
  echo "❌ CHAIN INVALID"
  echo "   Policy may be void. Contact support."
  exit 1
elif [ "$WARNINGS" -gt 0 ]; then
  echo "⚠️  CHAIN VALID (with warnings)"
  echo "   Review warnings above."
  exit 0
else
  echo "✅ CHAIN VALID"
  echo "   All attestations verified."
  exit 0
fi
