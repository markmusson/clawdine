#!/bin/bash
# Clawdsure Chain Pinning
# Auto-detects pinning method (w3 or pinata) and uploads chain
set -euo pipefail

DATA_DIR="${CLAWDSURE_DIR:-$HOME/.openclaw/workspace/.clawdsure}"
CHAIN_FILE="$DATA_DIR/chain.jsonl"

if [ ! -f "$CHAIN_FILE" ]; then
  echo "❌ No chain.jsonl found"
  exit 1
fi

SEQ=$(wc -l < "$CHAIN_FILE" | tr -d ' ')
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

pin_with_w3() {
  if ! command -v w3 >/dev/null 2>&1; then
    return 1
  fi
  
  # Check if authorized
  if w3 account ls 2>&1 | grep -q "not been authorized"; then
    return 1
  fi
  
  # Upload
  CID=$(w3 up "$CHAIN_FILE" --no-wrap 2>&1 | grep -oE "bafy[a-z0-9]+" | head -1 || true)
  if [ -n "$CID" ]; then
    echo "$CID"
    return 0
  fi
  return 1
}

pin_with_pinata() {
  JWT_FILE="$DATA_DIR/.pinata-jwt"
  if [ ! -f "$JWT_FILE" ]; then
    return 1
  fi
  
  PINATA_JWT=$(cat "$JWT_FILE")
  
  # Health check first - test auth
  AUTH_CHECK=$(curl -s -X GET "https://api.pinata.cloud/data/testAuthentication" \
    -H "Authorization: Bearer $PINATA_JWT" 2>/dev/null || echo '{}')
  
  if echo "$AUTH_CHECK" | grep -q "Unauthorized"; then
    # JWT invalid or expired - log warning
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) PINATA_JWT_INVALID" >> "$DATA_DIR/pinning-errors.log"
    return 1
  fi
  
  # Try V3 API first (newer keys use this)
  RESPONSE=$(curl -s -X POST "https://uploads.pinata.cloud/v3/files" \
    -H "Authorization: Bearer $PINATA_JWT" \
    -F "file=@$CHAIN_FILE" \
    -F "name=clawdsure-chain-seq$SEQ" 2>/dev/null || echo '{}')
  
  CID=$(echo "$RESPONSE" | jq -r '.data.cid // empty' 2>/dev/null || echo "")
  if [ -n "$CID" ] && [ "$CID" != "null" ]; then
    echo "$CID"
    return 0
  fi
  
  # Fallback to legacy API
  RESPONSE=$(curl -s -X POST "https://api.pinata.cloud/pinning/pinFileToIPFS" \
    -H "Authorization: Bearer $PINATA_JWT" \
    -F "file=@$CHAIN_FILE" \
    -F "pinataMetadata={\"name\":\"clawdsure-chain-seq$SEQ\"}" 2>/dev/null || echo '{}')
  
  CID=$(echo "$RESPONSE" | jq -r '.IpfsHash // empty' 2>/dev/null || echo "")
  if [ -n "$CID" ] && [ "$CID" != "null" ]; then
    echo "$CID"
    return 0
  fi
  
  # Log failure for debugging
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) PIN_FAILED: $RESPONSE" >> "$DATA_DIR/pinning-errors.log"
  return 1
}

# Try pinning methods in order
CID=""

# Method 1: web3.storage (w3)
if [ -z "$CID" ]; then
  CID=$(pin_with_w3 2>/dev/null || true)
  if [ -n "$CID" ]; then
    METHOD="w3"
  fi
fi

# Method 2: Pinata
if [ -z "$CID" ]; then
  CID=$(pin_with_pinata 2>/dev/null || true)
  if [ -n "$CID" ]; then
    METHOD="pinata"
  fi
fi

# Output result
if [ -n "$CID" ]; then
  echo "{\"ts\":\"$TIMESTAMP\",\"seq\":$SEQ,\"cid\":\"$CID\",\"method\":\"$METHOD\"}" >> "$DATA_DIR/pins.jsonl"
  echo "$CID"
  exit 0
else
  echo "none"
  exit 0  # Don't fail - pinning is optional
fi
