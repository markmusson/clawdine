#!/bin/bash
# Clawdsure Daily Attestation
# Token-efficient: Silent on success, only alerts on issues
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${CLAWDSURE_DIR:-$HOME/.openclaw/workspace/.clawdsure}"
API_BASE="${CLAWDSURE_API:-https://api.clawdsure.io/v1}"
SILENT_MODE="${CLAWDSURE_SILENT:-true}"

# Ensure we have identity
if [ ! -f "$DATA_DIR/agent.key" ]; then
  echo "❌ CLAWDSURE: Not enrolled. Run: bash scripts/enroll.sh"
  exit 1
fi

cd "$DATA_DIR"

# Load identity
FINGERPRINT=$(shasum -a 256 agent.pub | cut -c1-64)
AGENT_ID="CLWD-$(echo $FINGERPRINT | cut -c1-8 | tr 'a-f' 'A-F')"

# Step 1: Security audit
AUDIT_OUTPUT=$(openclaw security audit 2>&1 || true)

CRITICAL=$(echo "$AUDIT_OUTPUT" | grep -oE '[0-9]+ critical' | grep -oE '[0-9]+' | head -1 || echo "0")
WARN=$(echo "$AUDIT_OUTPUT" | grep -oE '[0-9]+ warn' | grep -oE '[0-9]+' | head -1 || echo "0")
INFO=$(echo "$AUDIT_OUTPUT" | grep -oE '[0-9]+ info' | grep -oE '[0-9]+' | head -1 || echo "0")
VERSION=$(openclaw --version 2>&1 | tail -1 || echo "unknown")

CRITICAL=${CRITICAL:-0}
WARN=${WARN:-0}
INFO=${INFO:-0}

if [ "$CRITICAL" -gt 0 ]; then
  RESULT="FAIL"
else
  RESULT="PASS"
fi

# Step 2: Build attestation
if [ -f chain.jsonl ] && [ -s chain.jsonl ]; then
  PREV_HASH=$(tail -1 chain.jsonl | shasum -a 256 | cut -c1-64)
  SEQ=$(($(wc -l < chain.jsonl | tr -d ' ') + 1))
else
  echo "❌ CLAWDSURE: No chain.jsonl - run enroll.sh first"
  exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

ATTESTATION=$(cat << EOF
{"seq":$SEQ,"prev":"$PREV_HASH","ts":"$TIMESTAMP","agent":"$AGENT_ID","result":"$RESULT","critical":$CRITICAL,"warn":$WARN,"info":$INFO,"version":"$VERSION"}
EOF
)

# Sign
SIG=$(echo -n "$ATTESTATION" | openssl dgst -sha256 -sign agent.key 2>/dev/null | base64 | tr -d '\n')
SIGNED="${ATTESTATION%\}},\"sig\":\"$SIG\"}"

# Append to chain
echo "$SIGNED" >> chain.jsonl

# Step 3: Pin to IPFS (optional)
CID=$(bash "$SCRIPT_DIR/pin-chain.sh" 2>/dev/null || echo "none")

# Step 4: Report to UW platform
REPORT=$(cat << EOF
{"action":"attestation","agent":{"id":"$AGENT_ID","fingerprint":"$FINGERPRINT"},"attestation":$SIGNED,"chain":{"length":$SEQ,"prevHash":"$PREV_HASH"}}
EOF
)

REPORT_SIG=$(echo -n "$REPORT" | openssl dgst -sha256 -sign agent.key 2>/dev/null | base64 | tr -d '\n')

API_RESPONSE=""
if curl -s --max-time 5 "$API_BASE/health" >/dev/null 2>&1; then
  API_RESPONSE=$(curl -s -X POST "$API_BASE/attestation" \
    -H "Content-Type: application/json" \
    -H "X-Agent-ID: $AGENT_ID" \
    -H "X-Agent-Signature: $REPORT_SIG" \
    -d "$REPORT" 2>/dev/null || echo '{"status":"offline"}')
fi

# Step 5: Output decision (token efficiency)
# Only output if there's something that needs attention

if [ "$RESULT" = "FAIL" ]; then
  # CRITICAL ALERT - needs attention
  echo "🚨 CLAWDSURE ALERT: $AGENT_ID"
  echo "Result: FAIL ($CRITICAL critical findings)"
  echo "You have 48h to remediate before chain break!"
  echo "Run: openclaw security audit"
  exit 1
fi

# Check for chain gap risk (warn if >36h since last attestation)
if [ -f chain.jsonl ] && [ $(wc -l < chain.jsonl | tr -d ' ') -gt 1 ]; then
  LAST_TS=$(tail -2 chain.jsonl | head -1 | jq -r '.ts' 2>/dev/null || echo "")
  if [ -n "$LAST_TS" ]; then
    # Convert timestamps and check gap
    LAST_EPOCH=$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "$LAST_TS" +%s 2>/dev/null || echo "0")
    NOW_EPOCH=$(date +%s)
    GAP_HOURS=$(( (NOW_EPOCH - LAST_EPOCH) / 3600 ))
    if [ "$GAP_HOURS" -gt 36 ]; then
      echo "⚠️ CLAWDSURE WARNING: ${GAP_HOURS}h since last attestation (48h = chain break)"
    fi
  fi
fi

# Silent success - log to file only
if [ "$SILENT_MODE" = "true" ]; then
  echo "$TIMESTAMP | #$SEQ | $RESULT | CID:${CID:-none}" >> "$DATA_DIR/attestation.log"
  exit 0
fi

# Verbose mode (for debugging)
echo "✅ Attestation #$SEQ: $RESULT | CID: $CID"
