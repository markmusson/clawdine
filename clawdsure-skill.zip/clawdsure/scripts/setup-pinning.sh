#!/bin/bash
# Clawdsure IPFS Pinning Setup
# One-time setup for web3.storage via GitHub auth
set -euo pipefail

DATA_DIR="${CLAWDSURE_DIR:-$HOME/.openclaw/workspace/.clawdsure}"

echo "🌐 IPFS PINNING SETUP"
echo "====================="
echo ""

# Check if w3 is installed
if ! command -v w3 >/dev/null 2>&1; then
  echo "Installing w3 CLI..."
  npm install -g @web3-storage/w3cli
fi

# Check if already authorized
ACCOUNT=$(w3 account ls 2>&1 || true)
if [[ ! "$ACCOUNT" =~ "not been authorized" ]]; then
  echo "✓ Already authorized"
  w3 account ls
else
  echo "Authorizing via GitHub..."
  echo ""
  echo "This will open your browser. Click 'Authorize' when prompted."
  echo "(GitHub developer accounts get free trial plan automatically)"
  echo ""
  read -p "Press Enter to continue..."
  
  w3 login --github
  
  echo ""
  echo "Waiting for authorization..."
  sleep 3
fi

# Check/create space
SPACE=$(w3 space ls 2>&1 | grep "clawdsure" || true)
if [ -z "$SPACE" ]; then
  echo ""
  echo "Creating clawdsure space..."
  w3 space create clawdsure
fi

# Use the space
w3 space use $(w3 space ls | grep clawdsure | awk '{print $2}')

# Provision if needed
echo ""
echo "Checking storage provision..."
PROVISION=$(w3 space info 2>&1 || true)
if [[ "$PROVISION" =~ "no storage" ]]; then
  echo "Provisioning free tier..."
  w3 space provision
fi

# Test upload
echo ""
echo "Testing upload..."
TEST_CID=$(echo "clawdsure-test-$(date +%s)" | w3 up --no-wrap - 2>&1 | grep -oE "bafy[a-z0-9]+" | head -1 || true)
if [ -n "$TEST_CID" ]; then
  echo "✓ Test upload successful: $TEST_CID"
  
  # Save config
  mkdir -p "$DATA_DIR"
  echo "w3" > "$DATA_DIR/.pinning-method"
  echo "✓ Pinning configured"
else
  echo "⚠️  Test upload failed. You can still use Clawdsure without IPFS."
fi

echo ""
echo "========================================"
echo "📋 SETUP COMPLETE"
echo "========================================"
echo ""
echo "Pinning method: web3.storage (w3)"
echo "Space: clawdsure"
echo ""
echo "Your attestations will now be pinned to IPFS automatically."
